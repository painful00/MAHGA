import argparse
import numpy as np
import scipy.sparse as sp
import torch
import sys
import random
import torch.nn.functional as F
import torch.optim as optim
import rcvae_pretrain
from utils import load_data, feature_tensor_normalize
import os
from tqdm import trange
from conf import Config
import dgl
from utils import load_data, score, EarlyStopping
from openhgnn import HAN
from rcvae_model import VAE
import torch.nn as nn
import copy


class HAN_LINK(nn.Module):

    def __init__(self, meta_paths, target_category, hidden_dim, label_num, num_heads, dropout, feature_sizes, category_index):
        super().__init__()
        #meta_paths = {"BSB":['b-s', 's-b'], "BUB":['b-u', 'u-b'], "BUBLB":['b-u', 'u-b', 'b-l', 'l-b'], "BUBSB":['b-u', 'u-b', 'b-s', 's-b'], "SBS":['s-b', 'b-s'], "UBU":['u-b', 'b-u'], "LBL":['l-b', 'b-l']}
        meta_paths = {"PAP": ['paper_author', 'author_paper'], "PSP": ['paper_subject', 'subject_paper'], "APA": ['author_paper', 'paper_author'], "SPS": ['subject_paper', 'paper_subject']}
        #meta_paths = {"MAM": ['M-A', 'A-M'], "MDM": ['M-D', 'D-M'], "AMA": ['A-M', 'M-A'], "DMD": ['D-M', 'M-D']}
        #self.model = HAN(meta_paths, [target_category, "s", "u", "l"], feature_sizes[category_index[target_category]], hidden_dim, hidden_dim, num_heads, dropout)
        self.model = HAN(meta_paths, [target_category, "author", "subject"], feature_sizes[category_index[target_category]],hidden_dim, hidden_dim, num_heads, dropout)
        #self.model = HAN(meta_paths, [target_category, "A", "D"], feature_sizes[category_index[target_category]], hidden_dim, hidden_dim, num_heads, dropout)
        self.category_index = category_index
        self.target_category = target_category
        self.classifier = nn.Linear(hidden_dim*2, 2)
        self.look_up_table = []
        for i, size in enumerate(feature_sizes):
            if i == category_index[target_category]:
                self.look_up_table.append(identical_map)
            else:
                self.look_up_table.append(nn.Linear(size, feature_sizes[category_index[target_category]]))

    def forward(self, g):
        feat_dict = {}
        for ntype in g.ntypes:
            feat_dict[ntype] = self.look_up_table[self.category_index[ntype]](g.ndata["h"][ntype])
        embeddings = self.model(g, feat_dict)

        return embeddings


def identical_map(x):
    return x