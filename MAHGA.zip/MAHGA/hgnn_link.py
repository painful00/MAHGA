import argparse
import numpy as np
import scipy.sparse as sp
import torch
import sys
import random
import torch.nn.functional as F
import torch.optim as optim
import rcvae_pretrain
from utils import load_data, feature_tensor_normalize
import os
from tqdm import trange
from conf import Config
import dgl
from utils import load_data, score, EarlyStopping, link_preliminary
from model.HAN_LINK import HAN_LINK
from sklearn import metrics

def auc_cal(output, labels):
    output = output.data.numpy()
    labels = labels.data.numpy()
    fpr, tpr, thresholds = metrics.roc_curve(labels, output, pos_label=1)
    auc = metrics.auc(fpr, tpr)
    return auc

# conf setting
model = "HAN"
dataset = "imdb"
gpu = -1    #   -1:cpu    >0:gpu
proDir = os.path.split(os.path.realpath(__file__))[0]
configPath = os.path.join(proDir, "conf.ini")
conf_path = os.path.abspath(configPath)
config = Config(file_path=conf_path, model=model, dataset=dataset, gpu=gpu, augmenter="")

# set random seed
random.seed(config.seed)
np.random.seed(config.seed)
torch.manual_seed(config.seed)
torch.cuda.manual_seed(config.seed)
dgl.seed(config.seed)

# data loading
g, idx_train, idx_val, idx_test, labels, category_index, feature_sizes, edge_types, meta_paths, target_category = load_data(dataset)
label_num = int(labels.max()+1)
target_feature_size = g.ndata["h"][target_category].size()[1]

train_ind_1, test_ind_1, train_ind_0, test_ind_0 = link_preliminary(g, dataset)

model = HAN_LINK(meta_paths, target_category, config.hidden_dim, label_num, config.num_heads, config.dropout, feature_sizes, category_index)
optimizer = torch.optim.AdamW(model.parameters(), lr=config.lr, weight_decay=config.weight_decay)
stopper = EarlyStopping(patience=config.patience)

if gpu >= 0:
    model.to("cuda:"+gpu)
    g.to("cuda:"+gpu)
    idx_train.to("cuda:"+gpu)
    idx_val.to("cuda:"+gpu)
    idx_test.to("cuda:"+gpu)
    labels.to("cuda:"+gpu)


# train
for epoch in range(config.max_epoch):
    model.train()
    embeddings = model(g)
    if dataset == "yelp":
        edges_types = ["b-s", "b-l", "b-u"]
    elif dataset == "acm":
        edges_types = {'paper_author', 'paper_subject'}
    elif dataset == "imdb":
        edges_types = {'M-A', 'M-D'}
    loss = 0
    logits_1_total = ""
    logits_0_total = ""
    for e in edges_types:
        if dataset == "yelp":
            source_type = e.split("-")[0]
            dest_type = e.split("-")[1]
        elif dataset == "acm":
            source_type = e.split("_")[0]
            dest_type = e.split("_")[1]
        elif dataset == "imdb":
            source_type = e.split("-")[0]
            dest_type = e.split("-")[1]
        logits_1 = F.sigmoid(torch.mul(embeddings[source_type][train_ind_1[e][0]], embeddings[dest_type][train_ind_1[e][1]]).sum(dim=1))
        if logits_1_total == "":
            logits_1_total = logits_1
        else:
            logits_1_total = torch.cat((logits_1_total,logits_1), dim=0)
        loss_1 = F.cosine_similarity(logits_1, torch.LongTensor(np.array([1 for i in range(logits_1.size()[0])])),dim=0)
        logits_0 = F.sigmoid(torch.mul(embeddings[source_type][train_ind_0[e][0]], embeddings[dest_type][train_ind_0[e][1]]).sum(dim=1))
        if logits_0_total == "":
            logits_0_total = logits_0
        else:
            logits_0_total = torch.cat((logits_0_total, logits_0), dim=0)
        loss_0 = F.cosine_similarity(logits_0, torch.LongTensor(np.array([0 for i in range(logits_0.size()[0])])),dim=0)
        loss += loss_1 + loss_0
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()
    label_1 = torch.LongTensor(np.array([1 for i in range(logits_1_total.size()[0])]))
    label_0 = torch.LongTensor(np.array([0 for i in range(logits_0_total.size()[0])]))
    print("train_auc:" + str(auc_cal(torch.cat((logits_1_total, logits_0_total),dim=0), torch.cat((label_1,label_0),dim=0))))

    # evaluation
    model.eval()
    with torch.no_grad():
        logits_1_total = ""
        logits_0_total = ""
        for e in edges_types:
            if dataset == "yelp":
                source_type = e.split("-")[0]
                dest_type = e.split("-")[1]
            elif dataset == "acm":
                source_type = e.split("_")[0]
                dest_type = e.split("_")[1]
            elif dataset == "imdb":
                source_type = e.split("-")[0]
                dest_type = e.split("-")[1]
            logits_1 = F.sigmoid(torch.mul(embeddings[source_type][test_ind_1[e][0]], embeddings[dest_type][test_ind_1[e][1]]).sum(dim=1))
            if logits_1_total == "":
                logits_1_total = logits_1
            else:
                logits_1_total = torch.cat((logits_1_total, logits_1), dim=0)
            logits_0 = F.sigmoid(torch.mul(embeddings[source_type][test_ind_0[e][0]], embeddings[dest_type][test_ind_0[e][1]]).sum(dim=1))
            if logits_0_total == "":
                logits_0_total = logits_0
            else:
                logits_0_total = torch.cat((logits_0_total, logits_0), dim=0)
    label_1 = torch.LongTensor(np.array([1 for i in range(logits_1_total.size()[0])]))
    label_0 = torch.LongTensor(np.array([0 for i in range(logits_0_total.size()[0])]))
    print("test_auc:" + str(
        auc_cal(torch.cat((logits_1_total, logits_0_total), dim=0), torch.cat((label_1, label_0), dim=0))))
